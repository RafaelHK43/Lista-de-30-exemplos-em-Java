package lsita.ex20;

public class App {
	public static void main(String[] args) {
        System.out.println("--- Exemplo 20: Liquidificador ---");

        Liquidificador meuLiquidificador = new Liquidificador();

        System.out.println("Estado inicial: " + meuLiquidificador);

        System.out.println("\n--- Tentativa de bater desligado ---");
        meuLiquidificador.bater(); 
        
        System.out.println("\n--- Ligando e definindo velocidade ---");
        meuLiquidificador.ligarDesligar();
        meuLiquidificador.definirVelocidade(3); 
        meuLiquidificador.bater(); 

        System.out.println("\n--- Tentativa de definir velocidade 0 ---");
        meuLiquidificador.definirVelocidade(0); 
        meuLiquidificador.bater(); 

        System.out.println("\n--- Desligando o liquidificador ---");
        meuLiquidificador.ligarDesligar(); 
        meuLiquidificador.bater(); 

        System.out.println("\nEstado final: " + meuLiquidificador);
    }
	
	
}
