package lsita.ex20;

public class Liquidificador {

	private boolean ligado;
    private int velocidade; 
    private static final int VELOCIDADE_MAXIMA = 5;

    public Liquidificador() {
        this.ligado = false;
        this.velocidade = 0;
    }

    public void ligarDesligar() {
        this.ligado = !this.ligado;
        if (!this.ligado) {
            this.velocidade = 0; 
            System.out.println("Liquidificador desligado.");
        } else {
            System.out.println("Liquidificador ligado.");
        }
    }

    public void definirVelocidade(int velocidade) {
        if (this.ligado) {
            if (velocidade >= 1 && velocidade <= VELOCIDADE_MAXIMA) {
                this.velocidade = velocidade;
                System.out.println("Velocidade definida para: " + this.velocidade);
            } else {
                System.out.println("Velocidade inválida. Deve ser entre 1 e " + VELOCIDADE_MAXIMA + ".");
            }
        } else {
            System.out.println("O liquidificador está desligado. Ligue-o para definir a velocidade.");
        }
    }

    public void bater() {
        if (this.ligado && this.velocidade > 0) {
            System.out.println("Batendo com o liquidificador na velocidade " + this.velocidade + "...");
        } else if (!this.ligado) {
            System.out.println("Não é possível bater: o liquidificador está desligado.");
        } else { 
            System.out.println("Não é possível bater: a velocidade está em 0. Defina uma velocidade maior que 0.");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public int getVelocidade() {
        return velocidade;
    }

    @Override
    public String toString() {
        if (ligado) {
            return "Liquidificador [ligado=" + ligado + ", velocidade=" + velocidade + "]";
        } else {
            return "Liquidificador [ligado=" + ligado + "]";
        }
    }
	
}
