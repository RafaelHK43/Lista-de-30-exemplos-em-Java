package lsita.ex14;

public class BateriaDeCelular {
	private int nivelCarga; 
    private final int NIVEL_MINIMO = 0;
    private final int NIVEL_MAXIMO = 100;

    public BateriaDeCelular(int cargaInicial) {
        if (cargaInicial >= NIVEL_MINIMO && cargaInicial <= NIVEL_MAXIMO) {
            this.nivelCarga = cargaInicial;
        } else {
            this.nivelCarga = 50;
            System.out.println("Carga inicial inválida. Usando 50%.");
        }
    }

    public void consumirCarga(int quantidade) {
        if (quantidade > 0) {
            this.nivelCarga -= quantidade;
            if (this.nivelCarga < NIVEL_MINIMO) {
                this.nivelCarga = NIVEL_MINIMO;
                System.out.println("Bateria esgotada!");
            }
            System.out.println("Consumindo carga. Nível atual: " + this.nivelCarga + "%");
        } else {
            System.out.println("A quantidade a consumir deve ser positiva.");
        }
    }

    public void carregar(int quantidade) {
        if (quantidade > 0) {
            this.nivelCarga += quantidade;
            if (this.nivelCarga > NIVEL_MAXIMO) {
                this.nivelCarga = NIVEL_MAXIMO;
                System.out.println("Bateria totalmente carregada!");
            }
            System.out.println("Carregando bateria. Nível atual: " + this.nivelCarga + "%");
        } else {
            System.out.println("A quantidade a carregar deve ser positiva.");
        }
    }

    public int getNivelCarga() {
        return nivelCarga;
    }

    @Override
    public String toString() {
        return "BateriaDeCelular [nível=" + nivelCarga + "%]";
    }
}
