package lsita.ex14;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 14: BateriaDeCelular ---");

	        BateriaDeCelular celular1 = new BateriaDeCelular(100); 
	        BateriaDeCelular celular2 = new BateriaDeCelular(10); 

	        System.out.println("Estado inicial Celular 1: " + celular1);
	        System.out.println("Estado inicial Celular 2: " + celular2);

	        System.out.println("\n--- Ações Celular 1 (Consumo) ---");
	        celular1.consumirCarga(30); 
	        celular1.consumirCarga(40); 
	        celular1.consumirCarga(35); 
	        System.out.println("\n--- Ações Celular 2 (Carga) ---");
	        celular2.carregar(20); 
	        celular2.carregar(80); 
	        celular2.carregar(10); 

	        System.out.println("\nEstado final Celular 1: " + celular1);
	        System.out.println("Estado final Celular 2: " + celular2);
	    }
	
	
}
