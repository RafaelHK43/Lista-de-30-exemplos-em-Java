package lsita.ex16;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 16: Impressora ---");

	        Impressora impressora1 = new Impressora(100, 50); 
	        Impressora impressora2 = new Impressora(0, 100); 

	        System.out.println("Estado inicial Impressora 1: " + impressora1);
	        System.out.println("Estado inicial Impressora 2: " + impressora2);

	        System.out.println("\n--- Tentativa de impressão Impressora 1 ---");
	        impressora1.imprimirPagina(); 
	        impressora1.imprimirPagina(); 
	        impressora1.imprimirPagina(); 
	        impressora1.imprimirPagina(); 
	        impressora1.imprimirPagina(); 

	        System.out.println("\n--- Tentativa de impressão Impressora 2 (sem papel) ---");
	        impressora2.imprimirPagina(); 

	        System.out.println("\n--- Reabastecendo Impressora 2 ---");
	        impressora2.reabastecerPapel(50);
	        impressora2.reabastecerTinta(100);
	        impressora2.imprimirPagina(); 

	        System.out.println("\nEstado final Impressora 1: " + impressora1);
	        System.out.println("Estado final Impressora 2: " + impressora2);
	    }
	
	
}
