package lsita.ex16;

public class Impressora {

	 private int paginasDisponiveis;
	    private int tintaDisponivel; 
	    private static final int MAX_PAGINAS = 500;

	    public Impressora(int paginasInicial, int tintaInicial) {
	        this.paginasDisponiveis = paginasInicial;
	        this.tintaDisponivel = tintaInicial;
	    }

	    public void imprimirPagina() {
	        if (this.paginasDisponiveis > 0 && this.tintaDisponivel >= 5) { 
	            this.paginasDisponiveis--;
	            this.tintaDisponivel -= 5;
	            System.out.println("Página impressa com sucesso. Restam " + this.paginasDisponiveis + " páginas e " + this.tintaDisponivel + "ml de tinta.");
	        } else if (this.paginasDisponiveis <= 0) {
	            System.out.println("Erro: Sem papel para imprimir.");
	        } else { 
	            System.out.println("Erro: Tinta insuficiente para imprimir uma página.");
	        }
	    }

	    public void reabastecerPapel(int quantidade) {
	        if (quantidade > 0) {
	            this.paginasDisponiveis += quantidade;
	            if (this.paginasDisponiveis > MAX_PAGINAS) {
	                this.paginasDisponiveis = MAX_PAGINAS;
	            }
	            System.out.println("Papel reabastecido. Total de páginas disponíveis: " + this.paginasDisponiveis);
	        } else {
	            System.out.println("A quantidade de papel a reabastecer deve ser positiva.");
	        }
	    }

	    public void reabastecerTinta(int quantidadeML) {
	        if (quantidadeML > 0) {
	            this.tintaDisponivel += quantidadeML;
	       
	            System.out.println("Tinta reabastecida em " + quantidadeML + "ml. Total de tinta: " + this.tintaDisponivel + "ml.");
	        } else {
	            System.out.println("A quantidade de tinta a reabastecer deve ser positiva.");
	        }
	    }

	    public int getPaginasDisponiveis() {
	        return paginasDisponiveis;
	    }

	    public int getTintaDisponivel() {
	        return tintaDisponivel;
	    }

	    @Override
	    public String toString() {
	        return "Impressora [páginas=" + paginasDisponiveis + ", tinta=" + tintaDisponivel + "ml]";
	    }
	
	
}
