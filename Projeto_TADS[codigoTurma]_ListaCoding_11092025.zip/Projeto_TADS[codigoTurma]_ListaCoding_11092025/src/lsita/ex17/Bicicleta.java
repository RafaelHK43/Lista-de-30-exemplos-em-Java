package lsita.ex17;

public class Bicicleta {

	 private int marchaAtual;
	    private int totalMarchas;
	    private boolean pedalando;

	    public Bicicleta(int totalMarchas) {
	        this.totalMarchas = totalMarchas;
	        this.marchaAtual = 1; 
	        this.pedalando = false;
	    }

	    public void pedalar() {
	        if (this.marchaAtual > 0) { 
	            this.pedalando = true;
	            System.out.println("Pedalando na marcha " + this.marchaAtual + "...");
	        } else {
	            System.out.println("Não é possível pedalar com a marcha desativada.");
	        }
	    }

	    public void pararDePedalar() {
	        this.pedalando = false;
	        System.out.println("Parou de pedalar.");
	    }

	    public void aumentarMarcha() {
	        if (this.marchaAtual < this.totalMarchas) {
	            this.marchaAtual++;
	            System.out.println("Marcha aumentada para: " + this.marchaAtual);
	            if (this.pedalando) {
	                System.out.println("Continuando a pedalar na nova marcha...");
	            }
	        } else {
	            System.out.println("Já está na marcha mais alta (" + this.totalMarchas + ").");
	        }
	    }

	    public void diminuirMarcha() {
	        if (this.marchaAtual > 1) {
	            this.marchaAtual--;
	            System.out.println("Marcha diminuída para: " + this.marchaAtual);
	            if (this.pedalando) {
	                System.out.println("Continuando a pedalar na nova marcha...");
	            }
	        } else {
	            System.out.println("Já está na primeira marcha.");
	        }
	    }

	    public void trocarMarcha(int novaMarcha) {
	        if (novaMarcha >= 1 && novaMarcha <= this.totalMarchas) {
	            this.marchaAtual = novaMarcha;
	            System.out.println("Marcha alterada diretamente para: " + this.marchaAtual);
	            if (this.pedalando) {
	                System.out.println("Continuando a pedalar na nova marcha...");
	            }
	        } else {
	            System.out.println("Marcha inválida. Deve ser entre 1 e " + this.totalMarchas + ".");
	        }
	    }

	    public int getMarchaAtual() {
	        return marchaAtual;
	    }

	    public int getTotalMarchas() {
	        return totalMarchas;
	    }

	    public boolean isPedalando() {
	        return pedalando;
	    }

	    @Override
	    public String toString() {
	        return "Bicicleta [marcha=" + marchaAtual + "/" + totalMarchas + ", pedalando=" + pedalando + "]";
	    }
	
}
