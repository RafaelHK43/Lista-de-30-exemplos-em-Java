package lsita.ex17;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 17: Bicicleta ---");

	        Bicicleta bike1 = new Bicicleta(18); 
	        Bicicleta bike2 = new Bicicleta(6);  

	        System.out.println("Estado inicial Bike 1: " + bike1);
	        System.out.println("Estado inicial Bike 2: " + bike2);

	        System.out.println("\n--- Trajeto Bike 1 ---");
	        bike1.pedalar();
	        bike1.aumentarMarcha(); 
	        bike1.aumentarMarcha();
	        bike1.trocarMarcha(10); 
	        bike1.aumentarMarcha();
	        bike1.pararDePedalar();

	        System.out.println("\n--- Trajeto Bike 2 ---");
	        bike2.trocarMarcha(4);
	        bike2.pedalar();
	        bike2.diminuirMarcha(); 
	        bike2.diminuirMarcha(); 
	        bike2.diminuirMarcha(); 
	        bike2.diminuirMarcha(); 
	        bike2.aumentarMarcha();
	        bike2.pararDePedalar();

	        System.out.println("\nEstado final Bike 1: " + bike1);
	        System.out.println("Estado final Bike 2: " + bike2);
	    }
	
	
}
