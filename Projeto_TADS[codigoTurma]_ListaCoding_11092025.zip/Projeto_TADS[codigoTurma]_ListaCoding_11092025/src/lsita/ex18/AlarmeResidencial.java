package lsita.ex18;

public class AlarmeResidencial {

	 private boolean armado;
	    private boolean eventoDisparado;

	    public AlarmeResidencial() {
	        this.armado = false;
	        this.eventoDisparado = false;
	    }

	    public void armar() {
	        this.armado = true;
	        this.eventoDisparado = false; 
	        System.out.println("Alarme armado.");
	    }

	    public void desarmar() {
	        this.armado = false;
	        this.eventoDisparado = false; 
	        System.out.println("Alarme desarmado.");
	    }

	    public void simularEvento() {
	        if (this.armado) {
	            this.eventoDisparado = true;
	            System.out.println("ALERTA! Evento detectado com o alarme armado!");
	         
	        } else {
	            System.out.println("Evento detectado, mas o alarme está desarmado. Nenhuma ação tomada.");
	        }
	    }

	    public boolean isArmado() {
	        return armado;
	    }

	    public boolean isEventoDisparado() {
	        return eventoDisparado;
	    }

	    @Override
	    public String toString() {
	        return "AlarmeResidencial [armado=" + armado + ", eventoDisparado=" + eventoDisparado + "]";
	    }
	
	
}
