package lsita.ex18;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 18: AlarmeResidencial ---");

        AlarmeResidencial alarmeCasa = new AlarmeResidencial();

        System.out.println("Estado inicial Alarme: " + alarmeCasa);

        System.out.println("\n--- Cenário 1: Evento com alarme desarmado ---");
        alarmeCasa.simularEvento(); 

        System.out.println("\n--- Armando o alarme ---");
        alarmeCasa.armar();
        System.out.println("Estado Alarme: " + alarmeCasa);

        System.out.println("\n--- Cenário 2: Evento com alarme armado ---");
        alarmeCasa.simularEvento();

        System.out.println("\n--- Desarmando o alarme ---");
        alarmeCasa.desarmar();
        System.out.println("Estado Alarme: " + alarmeCasa);
    }
	
	
}
