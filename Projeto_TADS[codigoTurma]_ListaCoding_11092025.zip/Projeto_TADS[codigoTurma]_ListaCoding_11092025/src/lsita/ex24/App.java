package lsita.ex24;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 24: Cofre ---");

        Cofre meuCofre = new Cofre("12345");

        System.out.println("Estado inicial do Cofre: " + meuCofre);

        System.out.println("\n--- Tentativa com senha errada ---");
        meuCofre.abrir("98765"); 
        meuCofre.alterarSenha("12345", "67890"); 

        System.out.println("\n--- Tentativa com senha correta ---");
        meuCofre.abrir("12345"); 

        System.out.println("\n--- Alterando senha ---");
        meuCofre.alterarSenha("12345", "67890"); 
        meuCofre.alterarSenha("12345", "novaSenha123");
        meuCofre.alterarSenha("novaSenha123", "senhaFinal456");

        System.out.println("\n--- Tentando abrir com a nova senha ---");
        meuCofre.abrir("novaSenha123");
        meuCofre.abrir("senhaFinal456"); 

        System.out.println("\n--- Fechando o cofre ---");
        meuCofre.fechar();

        System.out.println("\nEstado final do Cofre: " + meuCofre);
    }
	
	
}
