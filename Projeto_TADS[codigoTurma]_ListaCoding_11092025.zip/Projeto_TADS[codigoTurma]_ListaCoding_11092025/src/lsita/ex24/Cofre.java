package lsita.ex24;

public class Cofre {
	private String senha;
    private boolean aberto;

    public Cofre(String senhaInicial) {
        this.senha = senhaInicial;
        this.aberto = false;
    }

    public void abrir(String senhaTentativa) {
        if (this.senha.equals(senhaTentativa)) {
            this.aberto = true;
            System.out.println("Cofre aberto com sucesso!");
        } else {
            System.out.println("Senha incorreta. O cofre permanece fechado.");
        }
    }

    public void fechar() {
        if (this.aberto) {
            this.aberto = false;
            System.out.println("Cofre fechado.");
        } else {
            System.out.println("O cofre já está fechado.");
        }
    }

    public void alterarSenha(String senhaAntiga, String novaSenha) {
        if (this.aberto) {
            if (this.senha.equals(senhaAntiga)) {
                this.senha = novaSenha;
                System.out.println("Senha alterada com sucesso!");
            } else {
                System.out.println("Senha antiga incorreta. Não foi possível alterar a senha.");
            }
        } else {
            System.out.println("O cofre precisa estar aberto para alterar a senha.");
        }
    }

    public boolean isAberto() {
        return aberto;
    }

    @Override
    public String toString() {
        return "Cofre [aberto=" + aberto + "]";
    }

}
