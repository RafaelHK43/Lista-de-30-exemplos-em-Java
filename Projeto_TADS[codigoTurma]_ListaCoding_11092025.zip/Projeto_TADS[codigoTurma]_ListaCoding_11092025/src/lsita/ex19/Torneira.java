package lsita.ex19;

public class Torneira {

	private boolean aberta;
    private double intensidadeFluxo; 
    private final double FLUXO_MINIMO = 0.0;
    private final double FLUXO_MAXIMO = 1.0;

    public Torneira() {
        this.aberta = false;
        this.intensidadeFluxo = 0.0;
    }

    public void abrir() {
        if (!this.aberta) {
            this.aberta = true;
            System.out.println("Torneira aberta. Fluxo atual: " + this.intensidadeFluxo);
        } else {
            System.out.println("Torneira já está aberta.");
        }
    }

    public void fechar() {
        if (this.aberta) {
            this.aberta = false;
            this.intensidadeFluxo = 0.0; 
            System.out.println("Torneira fechada.");
        } else {
            System.out.println("Torneira já está fechada.");
        }
    }

    public void regularFluxo(double novaIntensidade) {
        if (this.aberta) {
            if (novaIntensidade >= FLUXO_MINIMO && novaIntensidade <= FLUXO_MAXIMO) {
                this.intensidadeFluxo = novaIntensidade;
                System.out.println("Intensidade do fluxo ajustada para: " + this.intensidadeFluxo);
            } else {
                System.out.println("Intensidade de fluxo inválida. Deve ser entre " + FLUXO_MINIMO + " e " + FLUXO_MAXIMO + ".");
            }
        } else {
            System.out.println("A torneira está fechada. Abra-a para regular o fluxo.");
        }
    }

    public boolean isAberta() {
        return aberta;
    }

    public double getIntensidadeFluxo() {
        return intensidadeFluxo;
    }

    @Override
    public String toString() {
        return "Torneira [aberta=" + aberta + ", fluxo=" + intensidadeFluxo + "]";
    }
	
	
	
}
