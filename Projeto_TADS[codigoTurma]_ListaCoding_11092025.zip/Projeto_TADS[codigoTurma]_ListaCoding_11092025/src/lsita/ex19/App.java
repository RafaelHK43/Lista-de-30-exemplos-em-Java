package lsita.ex19;

public class App {

	  public static void main(String[] args) {
	        System.out.println("--- Exemplo 19: Torneira ---");

	        Torneira torneiraCozinha = new Torneira();
	        Torneira torneiraBanheiro = new Torneira();

	        System.out.println("Estado inicial Torneira Cozinha: " + torneiraCozinha);
	        System.out.println("Estado inicial Torneira Banheiro: " + torneiraBanheiro);

	        System.out.println("\n--- Ações Torneira Cozinha ---");
	        torneiraCozinha.abrir();
	        torneiraCozinha.regularFluxo(0.5); 
	        torneiraCozinha.regularFluxo(0.8); 
	        torneiraCozinha.fechar();

	        System.out.println("\n--- Ações Torneira Banheiro ---");
	        torneiraBanheiro.abrir();
	        torneiraBanheiro.regularFluxo(0.2); 
	        torneiraBanheiro.abrir(); 
	        torneiraBanheiro.regularFluxo(1.0); 
	        torneiraBanheiro.fechar();

	        System.out.println("\nEstado final Torneira Cozinha: " + torneiraCozinha);
	        System.out.println("Estado final Torneira Banheiro: " + torneiraBanheiro);
	    }
	
	
}
