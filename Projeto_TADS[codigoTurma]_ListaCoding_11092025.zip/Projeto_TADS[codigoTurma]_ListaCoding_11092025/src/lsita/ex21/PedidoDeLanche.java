package lsita.ex21;

public class PedidoDeLanche {

	private String tamanho; 
    private boolean queijoAdicional;
    private boolean baconAdicional;
    private double precoBase;

    public PedidoDeLanche(String tamanho, boolean queijoAdicional, boolean baconAdicional) {
        this.tamanho = tamanho;
        this.queijoAdicional = queijoAdicional;
        this.baconAdicional = baconAdicional;
        this.precoBase = calcularPrecoBase();
    }

    private double calcularPrecoBase() {
        switch (this.tamanho.toLowerCase()) {
            case "pequeno":
                return 10.00;
            case "medio":
                return 12.00;
            case "grande":
                return 15.00;
            default:
                System.out.println("Tamanho de lanche '" + this.tamanho + "' inválido. Usando preço base de pequeno.");
                this.tamanho = "pequeno"; 
                return 10.00;
        }
    }

    public double calcularPrecoFinal() {
        double precoFinal = this.precoBase;
        double custoQueijo = 2.00; 
        double custoBacon = 3.00; 

        if (this.queijoAdicional) {
            precoFinal += custoQueijo;
        }
        if (this.baconAdicional) {
            precoFinal += custoBacon;
        }
        return precoFinal;
    }

    public String getTamanho() {
        return tamanho;
    }

    public boolean temQueijoAdicional() {
        return queijoAdicional;
    }

    public boolean temBaconAdicional() {
        return baconAdicional;
    }

    @Override
    public String toString() {
        return "PedidoDeLanche [tamanho=" + tamanho + ", queijo=" + queijoAdicional + ", bacon=" + baconAdicional + ", preco=" + String.format("%.2f", calcularPrecoFinal()) + "]";
    }
	
}
