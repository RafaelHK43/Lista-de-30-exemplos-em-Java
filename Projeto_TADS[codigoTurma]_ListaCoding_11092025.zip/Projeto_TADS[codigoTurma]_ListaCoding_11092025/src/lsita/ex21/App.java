package lsita.ex21;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 21: PedidoDeLanche ---");

	        PedidoDeLanche pedido1 = new PedidoDeLanche("medio", true, true);
  
	        PedidoDeLanche pedido2 = new PedidoDeLanche("grande", true, false);

	        PedidoDeLanche pedido3 = new PedidoDeLanche("pequeno", false, false);

	        System.out.println("--- Detalhes dos Pedidos ---");
	        System.out.println("Pedido 1: Tamanho=" + pedido1.getTamanho() + ", Queijo=" + pedido1.temQueijoAdicional() + ", Bacon=" + pedido1.temBaconAdicional() + ", Preço Final=R$" + String.format("%.2f", pedido1.calcularPrecoFinal()));
	        System.out.println("Pedido 2: Tamanho=" + pedido2.getTamanho() + ", Queijo=" + pedido2.temQueijoAdicional() + ", Bacon=" + pedido2.temBaconAdicional() + ", Preço Final=R$" + String.format("%.2f", pedido2.calcularPrecoFinal()));
	        System.out.println("Pedido 3: Tamanho=" + pedido3.getTamanho() + ", Queijo=" + pedido3.temQueijoAdicional() + ", Bacon=" + pedido3.temBaconAdicional() + ", Preço Final=R$" + String.format("%.2f", pedido3.calcularPrecoFinal()));

	        System.out.println("\n--- Informações resumidas ---");
	        System.out.println(pedido1);
	        System.out.println(pedido2);
	        System.out.println(pedido3);
	    }
	
	
}
