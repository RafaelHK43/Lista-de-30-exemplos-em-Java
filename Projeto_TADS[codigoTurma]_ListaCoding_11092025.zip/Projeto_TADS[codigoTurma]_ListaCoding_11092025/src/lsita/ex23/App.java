package lsita.ex23;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 23: Geladeira ---");

        Geladeira geladeira1 = new Geladeira(4);
        Geladeira geladeira2 = new Geladeira(2);

        System.out.println("Estado inicial Geladeira 1: " + geladeira1);
        System.out.println("Estado inicial Geladeira 2: " + geladeira2);

        System.out.println("\n--- Efeitos Porta Aberta vs. Fechada ---");

        geladeira1.abrirPorta();
        geladeira1.exibirStatus(); 

        geladeira1.fecharPorta();
        geladeira1.exibirStatus(); 

        geladeira2.abrirPorta();
        geladeira2.exibirStatus(); 

        System.out.println("\n--- Ajustando temperaturas ---");
        geladeira1.ajustarTemperatura(1); 
        geladeira2.ajustarTemperatura(7); 
        geladeira1.fecharPorta();
        geladeira2.fecharPorta();

        System.out.println("\nEstado final Geladeira 1: " + geladeira1);
        System.out.println("Estado final Geladeira 2: " + geladeira2);
    }
	
	
}
