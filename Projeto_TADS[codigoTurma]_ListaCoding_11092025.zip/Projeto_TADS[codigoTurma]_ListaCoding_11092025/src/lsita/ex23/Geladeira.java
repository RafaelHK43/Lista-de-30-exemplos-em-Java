package lsita.ex23;

public class Geladeira {

	 private int temperaturaInterna;
	    private boolean portaAberta;
	    private final int TEMPERATURA_MINIMA = 1; 
	    private final int TEMPERATURA_MAXIMA = 8; 

	    public Geladeira(int temperaturaInicial) {
	        if (temperaturaInicial >= TEMPERATURA_MINIMA && temperaturaInicial <= TEMPERATURA_MAXIMA) {
	            this.temperaturaInterna = temperaturaInicial;
	        } else {
	            this.temperaturaInterna = 4; 
	            System.out.println("Temperatura inicial inválida. Usando 4°C.");
	        }
	        this.portaAberta = false;
	    }

	    public void ajustarTemperatura(int novaTemperatura) {
	        if (novaTemperatura >= TEMPERATURA_MINIMA && novaTemperatura <= TEMPERATURA_MAXIMA) {
	            this.temperaturaInterna = novaTemperatura;
	            System.out.println("Temperatura interna ajustada para: " + this.temperaturaInterna + "°C");
	        } else {
	            System.out.println("Temperatura inválida. Deve ser entre " + TEMPERATURA_MINIMA + "°C e " + TEMPERATURA_MAXIMA + "°C.");
	        }
	    }

	    public void abrirPorta() {
	        if (!this.portaAberta) {
	            this.portaAberta = true;
	            System.out.println("Porta da geladeira aberta.");
	        } else {
	            System.out.println("A porta já está aberta.");
	        }
	    }

	    public void fecharPorta() {
	        if (this.portaAberta) {
	            this.portaAberta = false;
	            System.out.println("Porta da geladeira fechada.");
	        } else {
	            System.out.println("A porta já está fechada.");
	        }
	    }

	    public void exibirStatus() {
	        System.out.println("Status: Temperatura=" + this.temperaturaInterna + "°C, Porta=" + (this.portaAberta ? "Aberta" : "Fechada"));
	    }

	    public int getTemperaturaInterna() {
	        return temperaturaInterna;
	    }

	    public boolean isPortaAberta() {
	        return portaAberta;
	    }

	    @Override
	    public String toString() {
	        return "Geladeira [temperatura=" + temperaturaInterna + "°C, portaAberta=" + portaAberta + "]";
	    }
	
	
}
