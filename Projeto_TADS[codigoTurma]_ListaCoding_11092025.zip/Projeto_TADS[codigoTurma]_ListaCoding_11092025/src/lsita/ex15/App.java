package lsita.ex15;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 15: Semaforo ---");

        Semaforo cruzamento1 = new Semaforo();
        Semaforo cruzamento2 = new Semaforo();

        System.out.println("Estado inicial Cruzamento 1: " + cruzamento1);
        System.out.println("Estado inicial Cruzamento 2: " + cruzamento2);

        System.out.println("\n--- Ciclo Cruzamento 1 ---");
        cruzamento1.avancarEstado(); 
        cruzamento1.avancarEstado(); 
        cruzamento1.avancarEstado(); 
        cruzamento1.avancarEstado(); 

        System.out.println("\n--- Ciclo Cruzamento 2 ---");
        cruzamento2.avancarEstado(); 
        cruzamento2.avancarEstado(); 
        cruzamento2.avancarEstado();

        System.out.println("\nEstado final Cruzamento 1: " + cruzamento1);
        System.out.println("Estado final Cruzamento 2: " + cruzamento2);
    }
	
	
}
