package lsita.ex15;

public class Semaforo {

	private enum Estado {
        VERMELHO, AMARELO, VERDE
    }

    private Estado estadoAtual;

    public Semaforo() {
        this.estadoAtual = Estado.VERMELHO; 
    }

    public void avancarEstado() {
        switch (this.estadoAtual) {
            case VERMELHO:
                this.estadoAtual = Estado.VERDE;
                System.out.println("Sinal mudou para: VERDE");
                break;
            case VERDE:
                this.estadoAtual = Estado.AMARELO;
                System.out.println("Sinal mudou para: AMARELO");
                break;
            case AMARELO:
                this.estadoAtual = Estado.VERMELHO;
                System.out.println("Sinal mudou para: VERMELHO");
                break;
        }
    }

    public Estado getEstadoAtual() {
        return estadoAtual;
    }

    @Override
    public String toString() {
        return "Semaforo [estado=" + estadoAtual + "]";
    }
	
	
}
