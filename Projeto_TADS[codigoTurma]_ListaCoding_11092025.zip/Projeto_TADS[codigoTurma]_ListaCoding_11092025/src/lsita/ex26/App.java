package lsita.ex26;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 26: CaixaRegistradora ---");

        CaixaRegistradora caixa1 = new CaixaRegistradora();
        CaixaRegistradora caixa2 = new CaixaRegistradora();

        System.out.println("Estado inicial Caixa 1: " + caixa1);
        System.out.println("Estado inicial Caixa 2: " + caixa2);

        System.out.println("\n--- Vendas Caixa 1 ---");
        caixa1.registrarVenda(25.50);
        caixa1.registrarVenda(10.00);
        caixa1.registrarVenda(5.75);

        System.out.println("\n--- Vendas Caixa 2 ---");
        caixa2.registrarVenda(100.00);
        caixa2.registrarVenda(50.20);

        System.out.println("\n--- Fechando Caixas ---");
        caixa1.fecharCaixa();
        caixa2.fecharCaixa();

        System.out.println("\nEstado final Caixa 1 (após fechamento): " + caixa1);
        System.out.println("Estado final Caixa 2 (após fechamento): " + caixa2);

        System.out.println("\n--- Novas vendas após fechamento ---");
        caixa1.registrarVenda(15.00);
        System.out.println("Estado Caixa 1: " + caixa1);
    }
	
}
