package lsita.ex26;

public class CaixaRegistradora {

	 private double totalVendas;
	    private int numeroVendas;

	    public CaixaRegistradora() {
	        this.totalVendas = 0.0;
	        this.numeroVendas = 0;
	    }

	    public void registrarVenda(double valor) {
	        if (valor > 0) {
	            this.totalVendas += valor;
	            this.numeroVendas++;
	            System.out.println("Venda registrada: R$ " + String.format("%.2f", valor) + ". Total vendas: R$ " + String.format("%.2f", this.totalVendas));
	        } else {
	            System.out.println("O valor da venda deve ser positivo.");
	        }
	    }

	    public void fecharCaixa() {
	        System.out.println("--- Fechamento de Caixa ---");
	        System.out.println("Total de vendas realizadas: " + this.numeroVendas);
	        System.out.println("Valor total acumulado: R$ " + String.format("%.2f", this.totalVendas));
	      
	        this.totalVendas = 0.0;
	        this.numeroVendas = 0;
	        System.out.println("Caixa fechada e zerada para o próximo período.");
	    }

	    public double getTotalVendas() {
	        return totalVendas;
	    }

	    public int getNumeroVendas() {
	        return numeroVendas;
	    }

	    @Override
	    public String toString() {
	        return "CaixaRegistradora [vendas=" + numeroVendas + ", total=R$ " + String.format("%.2f", totalVendas) + "]";
	    }
	
	
}
