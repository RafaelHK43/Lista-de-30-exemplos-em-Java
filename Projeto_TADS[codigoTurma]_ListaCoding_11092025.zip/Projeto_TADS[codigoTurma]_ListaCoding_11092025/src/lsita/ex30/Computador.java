package lsita.ex30;

public class Computador {

	private boolean ligado;
    private String aplicativoAtivo; 

    public Computador() {
        this.ligado = false;
        this.aplicativoAtivo = "Nenhum";
    }

    public void ligarDesligar() {
        this.ligado = !this.ligado;
        if (!this.ligado) {
            this.aplicativoAtivo = "Nenhum"; 
            System.out.println("Computador desligado.");
        } else {
            System.out.println("Computador ligado.");
        }
    }

    public void reiniciar() {
        if (this.ligado) {
            System.out.println("Reiniciando o computador...");
            this.aplicativoAtivo = "Nenhum"; 
           
            System.out.println("Reinicialização concluída.");
            this.aplicativoAtivo = "Nenhum"; 
        } else {
            System.out.println("O computador está desligado. Não é possível reiniciar.");
        }
    }

    public void abrirAplicativo(String nomeApp) {
        if (this.ligado) {
            this.aplicativoAtivo = nomeApp;
            System.out.println("Aplicativo '" + this.aplicativoAtivo + "' aberto.");
        } else {
            System.out.println("O computador está desligado. Não é possível abrir aplicativos.");
        }
    }

    public void fecharAplicativo() {
        if (this.ligado) {
            if (!this.aplicativoAtivo.equals("Nenhum")) {
                System.out.println("Fechando aplicativo '" + this.aplicativoAtivo + "'.");
                this.aplicativoAtivo = "Nenhum";
            } else {
                System.out.println("Nenhum aplicativo aberto no momento.");
            }
        } else {
            System.out.println("O computador está desligado.");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public String getAplicativoAtivo() {
        return aplicativoAtivo;
    }

    @Override
    public String toString() {
        if (ligado) {
            return "Computador [ligado=" + ligado + ", appAtivo=" + aplicativoAtivo + "]";
        } else {
            return "Computador [ligado=" + ligado + "]";
        }
    }
	
}
