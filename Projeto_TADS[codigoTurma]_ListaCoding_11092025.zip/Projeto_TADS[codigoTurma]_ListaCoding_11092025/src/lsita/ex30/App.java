package lsita.ex30;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 30: Computador ---");

	        Computador meuPC = new Computador();

	        System.out.println("Estado inicial: " + meuPC);

	        System.out.println("\n--- Ligando e abrindo aplicativos ---");
	        meuPC.ligarDesligar();
	        meuPC.abrirAplicativo("Navegador Web");
	        meuPC.abrirAplicativo("Editor de Texto");
	        meuPC.abrirAplicativo("Planilha Eletrônica");

	        System.out.println("Estado atual: " + meuPC);

	        System.out.println("\n--- Fechando o aplicativo ---");
	        meuPC.fecharAplicativo();
	        System.out.println("Estado após fechar app: " + meuPC);

	        System.out.println("\n--- Reiniciando o computador ---");
	        meuPC.reiniciar();
	        System.out.println("Estado após reiniciar: " + meuPC);

	        System.out.println("\n--- Tentando operar com o computador desligado ---");
	        meuPC.abrirAplicativo("Jogo"); 
	        meuPC.reiniciar();

	        System.out.println("\n--- Ligando novamente ---");
	        meuPC.ligarDesligar(); 
	        meuPC.abrirAplicativo("Leitor de PDF");
	        System.out.println("Estado final: " + meuPC);
	    }
	
}
