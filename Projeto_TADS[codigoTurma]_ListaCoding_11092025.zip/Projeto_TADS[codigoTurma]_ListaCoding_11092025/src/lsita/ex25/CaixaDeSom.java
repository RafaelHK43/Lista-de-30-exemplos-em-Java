package lsita.ex25;

public class CaixaDeSom {

	private boolean ligada;
    private int volumeAtual;
    private boolean modoMudo;
    private final int VOLUME_MINIMO = 0;
    private final int VOLUME_MAXIMO = 100;

    public CaixaDeSom() {
        this.ligada = false;
        this.volumeAtual = 20; 
        this.modoMudo = false;
    }

    public void ligarDesligar() {
        this.ligada = !this.ligada;
        if (!this.ligada) {
            this.modoMudo = false; 
            System.out.println("Caixa de som desligada.");
        } else {
            System.out.println("Caixa de som ligada.");
        }
    }

    public void aumentarVolume() {
        if (this.ligada) {
            if (this.modoMudo) {
                this.modoMudo = false;
                System.out.println("Modo mudo desativado.");
            }
            if (this.volumeAtual < VOLUME_MAXIMO) {
                this.volumeAtual++;
                System.out.println("Volume aumentado para: " + this.volumeAtual);
            } else {
                System.out.println("Volume já está no máximo (" + VOLUME_MAXIMO + ").");
            }
        } else {
            System.out.println("A caixa de som está desligada.");
        }
    }

    public void diminuirVolume() {
        if (this.ligada) {
            if (this.modoMudo) {
                this.modoMudo = false; 
                System.out.println("Modo mudo desativado.");
            }
            if (this.volumeAtual > VOLUME_MINIMO) {
                this.volumeAtual--;
                System.out.println("Volume diminuído para: " + this.volumeAtual);
            } else {
                System.out.println("Volume já está no mínimo (" + VOLUME_MINIMO + ").");
            }
        } else {
            System.out.println("A caixa de som está desligada.");
        }
    }

    public void ativarDesativarMudo() {
        if (this.ligada) {
            this.modoMudo = !this.modoMudo;
            System.out.println("Modo mudo " + (this.modoMudo ? "ativado" : "desativado"));
        } else {
            System.out.println("A caixa de som está desligada.");
        }
    }

    public void setVolume(int volume) {
        if (this.ligada) {
            if (volume >= VOLUME_MINIMO && volume <= VOLUME_MAXIMO) {
                this.volumeAtual = volume;
                if (this.modoMudo && volume > 0) { 
                    this.modoMudo = false;
                    System.out.println("Modo mudo desativado.");
                }
                System.out.println("Volume ajustado para: " + this.volumeAtual);
            } else {
                System.out.println("Volume " + volume + " inválido. Deve ser entre " + VOLUME_MINIMO + " e " + VOLUME_MAXIMO + ".");
            }
        } else {
            System.out.println("A caixa de som está desligada.");
        }
    }

    public boolean isLigada() {
        return ligada;
    }

    public int getVolumeAtual() {
        return volumeAtual;
    }

    public boolean isModoMudo() {
        return modoMudo;
    }

    @Override
    public String toString() {
        String statusMudo = modoMudo ? " (Mudo)" : "";
        if (ligada) {
            return "CaixaDeSom [ligada=" + ligada + ", volume=" + volumeAtual + "%" + statusMudo + "]";
        } else {
            return "CaixaDeSom [ligada=" + ligada + "]";
        }
    }
	
	
}
