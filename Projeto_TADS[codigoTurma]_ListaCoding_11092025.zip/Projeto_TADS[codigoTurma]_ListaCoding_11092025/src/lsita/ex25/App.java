package lsita.ex25;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 25: CaixaDeSom ---");

	        CaixaDeSom caixa1 = new CaixaDeSom();

	        System.out.println("Estado inicial Caixa 1: " + caixa1);

	        System.out.println("\n--- Ações Caixa 1 ---");
	        caixa1.ligarDesligar();
	        caixa1.aumentarVolume(); 
	        caixa1.aumentarVolume();
	        caixa1.ativarDesativarMudo(); 
	        caixa1.aumentarVolume(); 
	        caixa1.diminuirVolume(); 
	        caixa1.setVolume(0); 
	        caixa1.ativarDesativarMudo(); 
	        caixa1.aumentarVolume(); 

	        System.out.println("\n--- Diferença Volume 0 e Mudo ---");
	        CaixaDeSom caixa2 = new CaixaDeSom();
	        caixa2.ligarDesligar();
	        caixa2.setVolume(0);
	        System.out.println("Caixa 2 com Volume 0: " + caixa2);

	        CaixaDeSom caixa3 = new CaixaDeSom();
	        caixa3.ligarDesligar();
	        caixa3.setVolume(50); 
	        caixa3.ativarDesativarMudo(); 
	        System.out.println("Caixa 3 com Mudo ativado: " + caixa3);

	        caixa3.ligarDesligar(); 

	        System.out.println("\nEstado final Caixa 1: " + caixa1);
	        System.out.println("Estado Caixa 2: " + caixa2);
	        System.out.println("Estado Caixa 3: " + caixa3);
	    }
	
	
}
