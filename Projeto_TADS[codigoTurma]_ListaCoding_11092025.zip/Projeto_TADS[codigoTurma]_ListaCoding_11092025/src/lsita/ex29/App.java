package lsita.ex29;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 29: TanqueDeAgua ---");

	        TanqueDeAgua tanquePrincipal = new TanqueDeAgua(1000.0); 

	        System.out.println("Estado inicial Tanque: " + tanquePrincipal);

	        System.out.println("\n--- Enchendo o tanque ---");
	        tanquePrincipal.encher(500.0);
	        tanquePrincipal.encher(600.0); 

	        System.out.println("\n--- Esvaziando o tanque ---");
	        tanquePrincipal.esvaziar(200.0);
	        tanquePrincipal.esvaziar(900.0); 

	        System.out.println("\nEstado final Tanque: " + tanquePrincipal);
	    }
	
}