package lsita.ex29;

public class TanqueDeAgua {

	private double nivelAtual; 
    private final double nivelMinimo = 0.0;
    private final double nivelMaximo;

    public TanqueDeAgua(double capacidadeTotal) {
        this.nivelMaximo = capacidadeTotal;
        this.nivelAtual = 0.0; 
    }

    public void encher(double quantidade) {
        if (quantidade > 0) {
            this.nivelAtual += quantidade;
            if (this.nivelAtual > this.nivelMaximo) {
                this.nivelAtual = this.nivelMaximo;
                System.out.println("Tanque cheio! Nível atual: " + String.format("%.2f", this.nivelAtual) + "L.");
            } else {
                System.out.println("Enchendo tanque. Nível atual: " + String.format("%.2f", this.nivelAtual) + "L.");
            }
        } else {
            System.out.println("A quantidade a encher deve ser positiva.");
        }
    }

    public void esvaziar(double quantidade) {
        if (quantidade > 0) {
            this.nivelAtual -= quantidade;
            if (this.nivelAtual < this.nivelMinimo) {
                this.nivelAtual = this.nivelMinimo;
                System.out.println("Tanque vazio! Nível atual: " + String.format("%.2f", this.nivelAtual) + "L.");
            } else {
                System.out.println("Esvaziando tanque. Nível atual: " + String.format("%.2f", this.nivelAtual) + "L.");
            }
        } else {
            System.out.println("A quantidade a esvaziar deve ser positiva.");
        }
    }

    public double getNivelAtual() {
        return nivelAtual;
    }

    public double getNivelMaximo() {
        return nivelMaximo;
    }

    @Override
    public String toString() {
        return "TanqueDeAgua [nível=" + String.format("%.2f", nivelAtual) + "L / " + String.format("%.2f", nivelMaximo) + "L]";
    }
	
}
