package lsita.ex13;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 13: MaquinaDeCafe ---");

        MaquinaDeCafe maquina1 = new MaquinaDeCafe(100, 500, 20); 
        MaquinaDeCafe maquina2 = new MaquinaDeCafe(5, 100, 5); 

        System.out.println("Estado inicial Máquina 1: " + maquina1);
        System.out.println("Estado inicial Máquina 2: " + maquina2);

        System.out.println("\n--- Ações Máquina 1 ---");
        maquina1.prepararBebida("Expresso", 1); 
        maquina1.prepararBebida("Cappuccino", 2); 
        maquina1.prepararBebida("Cafe com Leite", 0); 

        System.out.println("\n--- Ações Máquina 2 ---");
        maquina2.prepararBebida("Expresso", 1); 
        maquina2.reabastecer(50, 500, 10); 
        maquina2.prepararBebida("Expresso", 1); 

        System.out.println("\nEstado final Máquina 1: " + maquina1);
        System.out.println("Estado final Máquina 2: " + maquina2);
    }
	
	
}
