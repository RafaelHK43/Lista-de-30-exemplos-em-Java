package lsita.ex13;

public class MaquinaDeCafe {

	 private int cafeDisponivel; 
	    private int aguaDisponivel;
	    private int acucarDisponivel; 

	    public MaquinaDeCafe(int cafeInicial, int aguaInicial, int acucarInicial) {
	        this.cafeDisponivel = cafeInicial;
	        this.aguaDisponivel = aguaInicial;
	        this.acucarDisponivel = acucarInicial;
	    }

	    public void prepararBebida(String tipoBebida, int quantidadeAcucar) {
	        int cafeNecessario = 0;
	        int aguaNecessaria = 0;

	        switch (tipoBebida.toLowerCase()) {
	            case "expresso":
	                cafeNecessario = 10;
	                aguaNecessaria = 50;
	                break;
	            case "cappuccino":
	                cafeNecessario = 15;
	                aguaNecessaria = 150;
	                break;
	            case "cafe com leite":
	                cafeNecessario = 15;
	                aguaNecessaria = 180;
	                break;
	            default:
	                System.out.println("Tipo de bebida '" + tipoBebida + "' não reconhecido.");
	                return;
	        }

	        if (quantidadeAcucar > 0) {
	            if (this.acucarDisponivel < quantidadeAcucar) {
	                System.out.println("Não há açúcar suficiente para preparar " + tipoBebida + " com " + quantidadeAcucar + " colheres(s).");
	                return;
	            }
	        }

	        if (this.cafeDisponivel < cafeNecessario) {
	            System.out.println("Não há café suficiente para preparar " + tipoBebida + ".");
	            return;
	        }

	        if (this.aguaDisponivel < aguaNecessaria) {
	            System.out.println("Não há água suficiente para preparar " + tipoBebida + ".");
	            return;
	        }

	        this.cafeDisponivel -= cafeNecessario;
	        this.aguaDisponivel -= aguaNecessaria;
	        if (quantidadeAcucar > 0) {
	            this.acucarDisponivel -= quantidadeAcucar;
	        }

	        System.out.println("Preparando " + tipoBebida + " com " + quantidadeAcucar + " colher(es) de açúcar.");
	        System.out.println("Recursos restantes: Café=" + this.cafeDisponivel + "g, Água=" + this.aguaDisponivel + "ml, Açúcar=" + this.acucarDisponivel + " colheres.");
	    }

	    public void reabastecer(int cafe, int agua, int acucar) {
	        this.cafeDisponivel += cafe;
	        this.aguaDisponivel += agua;
	        this.acucarDisponivel += acucar;
	        System.out.println("Máquina reabastecida. Recursos atuais: Café=" + this.cafeDisponivel + "g, Água=" + this.aguaDisponivel + "ml, Açúcar=" + this.acucarDisponivel + " colheres.");
	    }

	    public int getCafeDisponivel() {
	        return cafeDisponivel;
	    }

	    public int getAguaDisponivel() {
	        return aguaDisponivel;
	    }

	    public int getAcucarDisponivel() {
	        return acucarDisponivel;
	    }

	    @Override
	    public String toString() {
	        return "MaquinaDeCafe [café=" + cafeDisponivel + "g, água=" + aguaDisponivel + "ml, açúcar=" + acucarDisponivel + " colheres]";
	    }
	
	
}
