package lsita.ex27;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 27: Termostato ---");

	        Termostato termostatoAmbiente1 = new Termostato();
	        Termostato termostatoAmbiente2 = new Termostato();

	        System.out.println("Estado inicial Termostato 1: " + termostatoAmbiente1);
	        System.out.println("Estado inicial Termostato 2: " + termostatoAmbiente2);

	        System.out.println("\n--- Configurações e Simulações ---");

	        termostatoAmbiente1.definirTemperatura(22.0);
	        termostatoAmbiente1.simularAmbiente(18.0); 
	        termostatoAmbiente1.simularAmbiente(22.5); 

	        System.out.println("\n");

	        termostatoAmbiente2.definirTemperatura(18.0);
	        termostatoAmbiente2.simularAmbiente(25.0); 
	        termostatoAmbiente2.simularAmbiente(19.0); 

	        System.out.println("\nEstado final Termostato 1: " + termostatoAmbiente1);
	        System.out.println("Estado final Termostato 2: " + termostatoAmbiente2);
	    }
	
	
}
