package lsita.ex27;

public class Termostato {

	private double temperaturaDesejada;
    private String modo; 

    public Termostato() {
        this.temperaturaDesejada = 20.0; 
        this.modo = "neutro";
    }

    public void definirTemperatura(double temperatura) {
        this.temperaturaDesejada = temperatura;
        System.out.println("Temperatura desejada definida para: " + this.temperaturaDesejada + "°C");
        atualizarModo();
    }

    public void simularAmbiente(double temperaturaAmbiente) {
        System.out.println("Simulando ambiente com " + temperaturaAmbiente + "°C.");
        if (temperaturaAmbiente < this.temperaturaDesejada - 1) { 
            this.modo = "aquecendo";
        } else if (temperaturaAmbiente > this.temperaturaDesejada + 1) { 
            this.modo = "resfriando";
        } else {
            this.modo = "neutro"; 
        }
        System.out.println("Termostato está: " + this.modo.toUpperCase());
    }

    private void atualizarModo() {
    }

    public double getTemperaturaDesejada() {
        return temperaturaDesejada;
    }

    public String getModo() {
        return modo;
    }

    @Override
    public String toString() {
        return "Termostato [desejada=" + temperaturaDesejada + "°C, modo=" + modo.toUpperCase() + "]";
    }
	
}
