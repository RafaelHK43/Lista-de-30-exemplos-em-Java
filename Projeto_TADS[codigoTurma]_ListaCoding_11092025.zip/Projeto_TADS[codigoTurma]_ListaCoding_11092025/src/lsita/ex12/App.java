package lsita.ex12;

import java.util.concurrent.TimeUnit;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 12: Cronometro ---");

        Cronometro crono1 = new Cronometro();
        Cronometro crono2 = new Cronometro();

        System.out.println("Estado inicial Cronômetro 1: " + crono1);
        System.out.println("Estado inicial Cronômetro 2: " + crono2);

        System.out.println("\n--- Ações Cronômetro 1 ---");
        crono1.iniciar();
        crono1.simularIncremento(TimeUnit.SECONDS.toMillis(5)); 
        crono1.simularIncremento(TimeUnit.SECONDS.toMillis(10)); 
        crono1.parar();
        crono1.simularIncremento(TimeUnit.SECONDS.toMillis(2)); 

        System.out.println("Estado Cronômetro 1: " + crono1);

        System.out.println("\n--- Ações Cronômetro 2 ---");
        crono2.iniciar();
        crono2.simularIncremento(TimeUnit.MINUTES.toMillis(1));
        crono2.simularIncremento(TimeUnit.SECONDS.toMillis(30)); 
        crono2.zerar();
        crono2.simularIncremento(TimeUnit.SECONDS.toMillis(5)); 

        System.out.println("\nEstado final Cronômetro 1: " + crono1);
        System.out.println("Estado final Cronômetro 2: " + crono2);
    }
	
	
	
}
