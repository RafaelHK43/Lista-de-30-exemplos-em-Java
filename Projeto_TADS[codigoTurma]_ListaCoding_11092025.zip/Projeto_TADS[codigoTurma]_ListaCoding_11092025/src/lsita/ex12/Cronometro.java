package lsita.ex12;

import java.util.concurrent.TimeUnit; 

public class Cronometro {

	 private long tempoDecorridoMillis;
	    private boolean ativo;

	    public Cronometro() {
	        this.tempoDecorridoMillis = 0;
	        this.ativo = false;
	    }

	    public void iniciar() {
	        if (!this.ativo) {
	            this.ativo = true;
	            System.out.println("Cronômetro iniciado.");
	        } else {
	            System.out.println("Cronômetro já está em execução.");
	        }
	    }

	    public void parar() {
	        if (this.ativo) {
	            this.ativo = false;
	            System.out.println("Cronômetro parado.");
	        } else {
	            System.out.println("Cronômetro já está parado.");
	        }
	    }

	    public void zerar() {
	        this.tempoDecorridoMillis = 0;
	        this.ativo = false; 
	        System.out.println("Cronômetro zerado.");
	    }

	    public void simularIncremento(long millis) {
	        if (this.ativo) {
	            this.tempoDecorridoMillis += millis;
	            System.out.println("Tempo decorrido: " + formatarTempo(this.tempoDecorridoMillis));
	        } else {
	            System.out.println("Cronômetro não está ativo para simular incremento.");
	        }
	    }

	    public String getTempoDecoridoFormatado() {
	        return formatarTempo(this.tempoDecorridoMillis);
	    }

	    private String formatarTempo(long millis) {
	        long horas = TimeUnit.MILLISECONDS.toHours(millis);
	        millis -= TimeUnit.HOURS.toMillis(horas);
	        long minutos = TimeUnit.MILLISECONDS.toMinutes(millis);
	        millis -= TimeUnit.MINUTES.toMillis(minutos);
	        long segundos = TimeUnit.MILLISECONDS.toSeconds(millis);

	        return String.format("%02d:%02d:%02d", horas, minutos, segundos);
	    }

	    public boolean isAtivo() {
	        return ativo;
	    }

	    @Override
	    public String toString() {
	        return "Cronometro [tempo=" + getTempoDecoridoFormatado() + ", ativo=" + ativo + "]";
	    }
	
	
	
}
