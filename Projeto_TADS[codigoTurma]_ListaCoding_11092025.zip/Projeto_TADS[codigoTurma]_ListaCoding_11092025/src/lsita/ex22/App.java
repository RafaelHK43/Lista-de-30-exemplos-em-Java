package lsita.ex22;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 22: FornoEletrico ---");

        FornoEletrico forno1 = new FornoEletrico();
        FornoEletrico forno2 = new FornoEletrico();

        System.out.println("Estado inicial Forno 1: " + forno1);
        System.out.println("Estado inicial Forno 2: " + forno2);

        System.out.println("\n--- Ações Forno 1 (Metas distintas) ---");
        forno1.ligarDesligar(); 
        forno1.definirTemperaturaAlvo(180); 

        System.out.println("\n--- Ações Forno 2 ---");
        forno2.ligarDesligar(); 
        forno2.definirTemperaturaAlvo(220); 

        System.out.println("\n--- Simulando aquecimento (5 ciclos) ---");
        for (int i = 0; i < 5; i++) {
            System.out.println("Ciclo " + (i + 1) + ":");
            forno1.simularAquecimento();
            forno2.simularAquecimento();
        }

        System.out.println("\n--- Desligando Forno 1 ---");
        forno1.ligarDesligar();
        forno1.simularAquecimento(); 

        System.out.println("\nEstado final Forno 1: " + forno1);
        System.out.println("Estado final Forno 2: " + forno2);
    }
	
}
