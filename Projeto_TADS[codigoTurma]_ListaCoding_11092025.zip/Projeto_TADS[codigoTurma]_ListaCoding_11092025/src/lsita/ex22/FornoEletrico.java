package lsita.ex22;

public class FornoEletrico {

	private boolean ligado;
    private int temperaturaAlvo; 
    private int temperaturaAtual; 

    public FornoEletrico() {
        this.ligado = false;
        this.temperaturaAlvo = 0;
        this.temperaturaAtual = 25; 
    }

    public void ligarDesligar() {
        this.ligado = !this.ligado;
        if (!this.ligado) {
            this.temperaturaAlvo = 0; 
            System.out.println("Forno desligado.");
        } else {
            System.out.println("Forno ligado.");
        }
    }

    public void definirTemperaturaAlvo(int temperatura) {
        if (this.ligado) {
            this.temperaturaAlvo = temperatura;
            System.out.println("Temperatura alvo definida para: " + this.temperaturaAlvo + "°C");
        } else {
            System.out.println("O forno está desligado. Ligue-o para definir a temperatura.");
        }
    }

    public void simularAquecimento() {
        if (this.ligado) {
            if (this.temperaturaAtual < this.temperaturaAlvo) {
                this.temperaturaAtual += 5; 
                if (this.temperaturaAtual > this.temperaturaAlvo) {
                    this.temperaturaAtual = this.temperaturaAlvo;
                }
                System.out.println("Aquecendo... Temperatura atual: " + this.temperaturaAtual + "°C");
            } else if (this.temperaturaAtual > this.temperaturaAlvo) {
                this.temperaturaAtual -= 2; 
                if (this.temperaturaAtual < this.temperaturaAlvo) {
                    this.temperaturaAtual = this.temperaturaAlvo;
                }
                System.out.println("Resfriando... Temperatura atual: " + this.temperaturaAtual + "°C");
            } else {
                System.out.println("Forno na temperatura alvo (" + this.temperaturaAlvo + "°C).");
            }
        } else {
            System.out.println("O forno está desligado. Temperatura ambiente: " + this.temperaturaAtual + "°C");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public int getTemperaturaAlvo() {
        return temperaturaAlvo;
    }

    public int getTemperaturaAtual() {
        return temperaturaAtual;
    }

    @Override
    public String toString() {
        if (ligado) {
            return "FornoEletrico [ligado=" + ligado + ", alvo=" + temperaturaAlvo + "°C, atual=" + temperaturaAtual + "°C]";
        } else {
            return "FornoEletrico [ligado=" + ligado + ", temperaturaAmbiente=" + temperaturaAtual + "°C]";
        }
    }
	
}
