package lsita.ex28;

public class SensorDePresenca {

	private boolean ativado;
    private boolean detectouPresenca;

    public SensorDePresenca() {
        this.ativado = false;
        this.detectouPresenca = false;
    }

    public void ativar() {
        this.ativado = true;
        this.detectouPresenca = false; 
        System.out.println("Sensor de presença ativado.");
    }

    public void desativar() {
        this.ativado = false;
        this.detectouPresenca = false; 
        System.out.println("Sensor de presença desativado.");
    }

    public void simularDeteccao() {
        if (this.ativado) {
            this.detectouPresenca = true;
            System.out.println("Presença detectada!");
            acionarDispositivo(); 
        } else {
            System.out.println("Sensor está desativado. Nenhuma detecção.");
        }
    }

    private void acionarDispositivo() {
        System.out.println("Dispositivo acionado (luz acesa, alarme soando, etc.).");
    }

    public boolean isAtivado() {
        return ativado;
    }

    public boolean isDetectouPresenca() {
        return detectouPresenca;
    }

    @Override
    public String toString() {
        return "SensorDePresenca [ativado=" + ativado + ", detectouPresenca=" + detectouPresenca + "]";
    }
	
	
}
