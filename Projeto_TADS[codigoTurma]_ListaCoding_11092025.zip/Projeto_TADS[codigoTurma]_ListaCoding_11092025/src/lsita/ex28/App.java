package lsita.ex28;

public class App {

	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 28: SensorDePresenca ---");

	        SensorDePresenca sensor1 = new SensorDePresenca();

	        System.out.println("Estado inicial Sensor: " + sensor1);

	        System.out.println("\n--- Cenário 1: Detecção com sensor ATIVADO ---");
	        sensor1.ativar();
	        sensor1.simularDeteccao();

	        System.out.println("\n--- Cenário 2: Detecção com sensor DESATIVADO ---");
	        sensor1.desativar();
	        sensor1.simularDeteccao(); 

	        System.out.println("\n--- Reativando e simulando novamente ---");
	        sensor1.ativar();
	        sensor1.simularDeteccao();

	        System.out.println("\nEstado final Sensor: " + sensor1);
	    }
	
	
}