package lista.ex11;

public class ControleDeVolume {
	 private int volumeAtual;
	    private final int volumeMinimo;
	    private final int volumeMaximo;

	    public ControleDeVolume(int volumeMinimo, int volumeMaximo) {
	        if (volumeMinimo < volumeMaximo) {
	            this.volumeMinimo = volumeMinimo;
	            this.volumeMaximo = volumeMaximo;
	            this.volumeAtual = volumeMinimo; 
	        } else {
	          
	            this.volumeMinimo = 0;
	            this.volumeMaximo = 100;
	            this.volumeAtual = 0;
	            System.out.println("Configuração de volume inválida. Usando padrão: Mínimo=" + this.volumeMinimo + ", Máximo=" + this.volumeMaximo);
	        }
	    }

	    public void aumentarVolume() {
	        if (this.volumeAtual < this.volumeMaximo) {
	            this.volumeAtual++;
	            System.out.println("Volume aumentado para: " + this.volumeAtual);
	        } else {
	            System.out.println("Volume já está no máximo (" + this.volumeMaximo + ").");
	        }
	    }

	    public void diminuirVolume() {
	        if (this.volumeAtual > this.volumeMinimo) {
	            this.volumeAtual--;
	            System.out.println("Volume diminuído para: " + this.volumeAtual);
	        } else {
	            System.out.println("Volume já está no mínimo (" + this.volumeMinimo + ").");
	        }
	    }

	    public void setVolume(int volume) {
	        if (volume >= this.volumeMinimo && volume <= this.volumeMaximo) {
	            this.volumeAtual = volume;
	            System.out.println("Volume ajustado para: " + this.volumeAtual);
	        } else {
	            System.out.println("Volume " + volume + " inválido. Deve ser entre " + this.volumeMinimo + " e " + this.volumeMaximo + ".");
	        }
	    }

	    public int getVolumeAtual() {
	        return volumeAtual;
	    }

	    public int getVolumeMinimo() {
	        return volumeMinimo;
	    }

	    public int getVolumeMaximo() {
	        return volumeMaximo;
	    }

	    @Override
	    public String toString() {
	        return "ControleDeVolume [volume=" + volumeAtual + ", min=" + volumeMinimo + ", max=" + volumeMaximo + "]";
	    }
}
