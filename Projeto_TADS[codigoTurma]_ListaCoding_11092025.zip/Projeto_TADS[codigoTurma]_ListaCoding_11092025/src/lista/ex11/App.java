package lista.ex11;

public class App {
	public static void main(String[] args) {
        System.out.println("--- Exemplo 11: ControleDeVolume ---");

        ControleDeVolume controle1 = new ControleDeVolume(0, 100);
      
        ControleDeVolume controle2 = new ControleDeVolume(1, 10);

        System.out.println("Estado inicial Controle 1: " + controle1);
        System.out.println("Estado inicial Controle 2: " + controle2);

        System.out.println("\n--- Ações Controle 1 ---");
        controle1.aumentarVolume();
        controle1.aumentarVolume(); 
        controle1.diminuirVolume(); 
        controle1.setVolume(50);
        controle1.setVolume(101); 
        controle1.setVolume(-5);  

        System.out.println("\n--- Ações Controle 2 ---");
        controle2.setVolume(5);
        controle2.aumentarVolume(); 
        controle2.diminuirVolume(); 
        controle2.diminuirVolume(); 
        controle2.setVolume(1); 
        controle2.diminuirVolume(); 
        controle2.setVolume(10); 
        controle2.aumentarVolume(); 

        System.out.println("\nEstado final Controle 1: " + controle1);
        System.out.println("Estado final Controle 2: " + controle2);
    }
}
