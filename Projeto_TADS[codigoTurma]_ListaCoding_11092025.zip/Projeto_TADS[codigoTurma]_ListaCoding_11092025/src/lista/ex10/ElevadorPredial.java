package lista.ex10;

public class ElevadorPredial {

	private int andarAtual;
    private int totalAndares;
    private int primeiroAndar; 

    public ElevadorPredial(int primeiroAndar, int ultimoAndar) {
        this.primeiroAndar = primeiroAndar;
        this.totalAndares = ultimoAndar;
        this.andarAtual = primeiroAndar; 
    }

    public void subir() {
        if (this.andarAtual < this.totalAndares) {
            this.andarAtual++;
            System.out.println("Subindo para o andar: " + this.andarAtual);
        } else {
            System.out.println("Já está no último andar (" + this.totalAndares + "). Impossível subir.");
        }
    }

    public void descer() {
        if (this.andarAtual > this.primeiroAndar) {
            this.andarAtual--;
            System.out.println("Descendo para o andar: " + this.andarAtual);
        } else {
            System.out.println("Já está no térreo/primeiro andar (" + this.primeiroAndar + "). Impossível descer.");
        }
    }

    public void irParaAndar(int andarDesejado) {
        if (andarDesejado >= this.primeiroAndar && andarDesejado <= this.totalAndares) {
            while (this.andarAtual < andarDesejado) {
                subir();
            }
            while (this.andarAtual > andarDesejado) {
                descer();
            }
            System.out.println("Chegou ao andar: " + this.andarAtual);
        } else {
            System.out.println("Andar " + andarDesejado + " inválido. O prédio tem do andar " + this.primeiroAndar + " ao " + this.totalAndares + ".");
        }
    }

    public int getAndarAtual() {
        return andarAtual;
    }

    public int getTotalAndares() {
        return totalAndares;
    }

    public int getPrimeiroAndar() {
        return primeiroAndar;
    }

    @Override
    public String toString() {
        return "ElevadorPredial [andarAtual=" + andarAtual + ", primeiroAndar=" + primeiroAndar + ", ultimoAndar=" + totalAndares + "]";
    }
}
