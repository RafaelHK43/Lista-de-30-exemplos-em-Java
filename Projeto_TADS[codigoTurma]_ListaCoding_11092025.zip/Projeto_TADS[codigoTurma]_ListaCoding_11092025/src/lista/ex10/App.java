package lista.ex10;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 10: ElevadorPredial ---");

       
        ElevadorPredial elevador1 = new ElevadorPredial(0, 10);
        ElevadorPredial elevador2 = new ElevadorPredial(1, 5); 

        System.out.println("Estado inicial Elevador 1: " + elevador1);
        System.out.println("Estado inicial Elevador 2: " + elevador2);

        System.out.println("\n--- Ações Elevador 1 ---");
        elevador1.irParaAndar(5);
        elevador1.subir(); 
        elevador1.descer(); 
        elevador1.irParaAndar(10); 
        elevador1.subir(); 
        elevador1.irParaAndar(0); 

        System.out.println("\n--- Ações Elevador 2 ---");
        elevador2.irParaAndar(3);
        elevador2.descer(); 
        elevador2.irParaAndar(5); 
        elevador2.descer(); 
        elevador2.irParaAndar(1); 
        elevador2.descer(); 

        System.out.println("\nEstado final Elevador 1: " + elevador1);
        System.out.println("Estado final Elevador 2: " + elevador2);
    }
}
