package lista.ex03;

public class CarroBasico {
	
	private boolean ligado;
    private int velocidadeAtual;
    private static final int VELOCIDADE_MAXIMA = 180; 

    public CarroBasico() {
        this.ligado = false;
        this.velocidadeAtual = 0;
    }

    public void ligarDesligar() {
        this.ligado = !this.ligado;
        if (!this.ligado) {
            this.velocidadeAtual = 0; 
        }
        System.out.println("Carro " + (this.ligado ? "ligado." : "desligado. Velocidade resetada."));
    }

    public void acelerar(int incremento) {
        if (this.ligado) {
            this.velocidadeAtual += incremento;
            if (this.velocidadeAtual > VELOCIDADE_MAXIMA) {
                this.velocidadeAtual = VELOCIDADE_MAXIMA;
            }
            System.out.println("Acelerando. Velocidade atual: " + this.velocidadeAtual + " km/h");
        } else {
            System.out.println("O carro está desligado. Não é possível acelerar.");
        }
    }

    public void frear(int decremento) {
        if (this.ligado) {
            this.velocidadeAtual -= decremento;
            if (this.velocidadeAtual < 0) {
                this.velocidadeAtual = 0;
            }
            System.out.println("Freando. Velocidade atual: " + this.velocidadeAtual + " km/h");
        } else {
            System.out.println("O carro está desligado. Não é possível frear.");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public int getVelocidadeAtual() {
        return velocidadeAtual;
    }

    @Override
    public String toString() {
        return "CarroBasico [ligado=" + ligado + ", velocidadeAtual=" + velocidadeAtual + " km/h]";
    }
}
