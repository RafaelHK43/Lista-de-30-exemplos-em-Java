package lista.ex03;

public class App {
	public static void main(String[] args) {
        System.out.println("--- Exemplo 3: CarroBasico ---");

        CarroBasico meuCarro = new CarroBasico();
        CarroBasico outroCarro = new CarroBasico();

        System.out.println("Estado inicial Meu Carro: " + meuCarro);
        System.out.println("Estado inicial Outro Carro: " + outroCarro);

        System.out.println("\n--- Ações Meu Carro ---");
        meuCarro.ligarDesligar();
        meuCarro.acelerar(50);
        meuCarro.acelerar(30);
        meuCarro.frear(20);
        meuCarro.ligarDesligar(); 

        System.out.println("Estado Meu Carro após uso: " + meuCarro);

        System.out.println("\n--- Ações Outro Carro ---");
        outroCarro.ligarDesligar();
        outroCarro.acelerar(80);
        outroCarro.frear(40);
        outroCarro.acelerar(100); 
        outroCarro.ligarDesligar(); 

        System.out.println("Estado Outro Carro após uso: " + outroCarro);
    }
}
