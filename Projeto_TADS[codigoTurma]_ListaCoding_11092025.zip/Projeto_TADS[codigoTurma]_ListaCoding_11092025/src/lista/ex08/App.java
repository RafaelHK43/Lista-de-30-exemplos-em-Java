package lista.ex08;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 8: RelogioDigital ---");

        RelogioDigital relogio1 = new RelogioDigital(10, 30);
        RelogioDigital relogio2 = new RelogioDigital(23, 59);

        System.out.println("Estado inicial Relógio 1: " + relogio1);
        System.out.println("Estado inicial Relógio 2: " + relogio2);

        System.out.println("\n--- Exibindo Horários Iniciais ---");
        relogio1.exibirHorario();
        relogio2.exibirHorario();

        System.out.println("\n--- Ajustando Horários ---");
        relogio1.ajustarHorario(12, 0);
        relogio2.ajustarHorario(0, 0); 
        relogio1.ajustarHorario(25, 0); 
        relogio2.ajustarHorario(1, 70); 
        System.out.println("\n--- Exibindo Horários Ajustados ---");
        relogio1.exibirHorario();
        relogio2.exibirHorario();

        System.out.println("\nEstado final Relógio 1: " + relogio1);
        System.out.println("Estado final Relógio 2: " + relogio2);
    }
}
