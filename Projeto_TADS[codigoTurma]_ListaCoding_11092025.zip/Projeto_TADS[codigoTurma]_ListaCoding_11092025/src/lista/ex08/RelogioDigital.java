package lista.ex08;

public class RelogioDigital {

    private int hora;
    private int minuto;

    public RelogioDigital(int hora, int minuto) {
        setHora(hora);
        setMinuto(minuto);
    }

    public void setHora(int hora) {
        if (hora >= 0 && hora < 24) {
            this.hora = hora;
        } else {
            System.out.println("Hora inválida. Deve ser entre 0 e 23.");
            this.hora = 0; 
        }
    }

    public void setMinuto(int minuto) {
        if (minuto >= 0 && minuto < 60) {
            this.minuto = minuto;
        } else {
            System.out.println("Minuto inválido. Deve ser entre 0 e 59.");
            this.minuto = 0; 
        }
    }

    public void ajustarHorario(int hora, int minuto) {
        setHora(hora);
        setMinuto(minuto);
        System.out.println("Horário ajustado para: " + formatarHora() + ":" + formatarMinuto());
    }

    private String formatarHora() {
        return (hora < 10) ? "0" + hora : String.valueOf(hora);
    }

    private String formatarMinuto() {
        return (minuto < 10) ? "0" + minuto : String.valueOf(minuto);
    }

    public void exibirHorario() {
        System.out.println("Horário atual: " + formatarHora() + ":" + formatarMinuto());
    }

    @Override
    public String toString() {
        return "RelogioDigital [horário=" + formatarHora() + ":" + formatarMinuto() + "]";
    }
}
