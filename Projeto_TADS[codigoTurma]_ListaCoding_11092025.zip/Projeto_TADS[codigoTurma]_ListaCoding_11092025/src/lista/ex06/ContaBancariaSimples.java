package lista.ex06;

public class ContaBancariaSimples {

	private double saldo;

    public ContaBancariaSimples(double saldoInicial) {
        if (saldoInicial >= 0) {
            this.saldo = saldoInicial;
        } else {
            this.saldo = 0;
            System.out.println("Saldo inicial não pode ser negativo. Saldo iniciado em 0.");
        }
    }

    public void depositar(double valor) {
        if (valor > 0) {
            this.saldo += valor;
            System.out.println("Depósito de R$ " + String.format("%.2f", valor) + " realizado. Novo saldo: R$ " + String.format("%.2f", this.saldo));
        } else {
            System.out.println("O valor do depósito deve ser positivo.");
        }
    }

    public void sacar(double valor) {
        if (valor > 0) {
            if (this.saldo >= valor) {
                this.saldo -= valor;
                System.out.println("Saque de R$ " + String.format("%.2f", valor) + " realizado. Novo saldo: R$ " + String.format("%.2f", this.saldo));
            } else {
                System.out.println("Saldo insuficiente para sacar R$ " + String.format("%.2f", valor) + ". Saldo atual: R$ " + String.format("%.2f", this.saldo));
            }
        } else {
            System.out.println("O valor do saque deve ser positivo.");
        }
    }

    public double getSaldo() {
        System.out.println("Saldo atual: R$ " + String.format("%.2f", this.saldo));
        return this.saldo;
    }

    @Override
    public String toString() {
        return "ContaBancariaSimples [saldo=R$ " + String.format("%.2f", saldo) + "]";
    }
}
