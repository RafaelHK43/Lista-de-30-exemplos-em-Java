package lista.ex06;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 6: ContaBancariaSimples ---");

        ContaBancariaSimples conta1 = new ContaBancariaSimples(1000.00);
        ContaBancariaSimples conta2 = new ContaBancariaSimples(50.00);

        System.out.println("Estado inicial Conta 1: " + conta1);
        System.out.println("Estado inicial Conta 2: " + conta2);

        System.out.println("\n--- Operações Conta 1 ---");
        conta1.depositar(200.50);
        conta1.sacar(150.00);
        conta1.getSaldo();

        System.out.println("\n--- Operações Conta 2 ---");
        conta2.depositar(30.00);
        conta2.sacar(100.00);
        conta2.sacar(20.00);
        conta2.getSaldo();

        System.out.println("\nEstado final Conta 1: " + conta1);
        System.out.println("Estado final Conta 2: " + conta2);
    }
}
