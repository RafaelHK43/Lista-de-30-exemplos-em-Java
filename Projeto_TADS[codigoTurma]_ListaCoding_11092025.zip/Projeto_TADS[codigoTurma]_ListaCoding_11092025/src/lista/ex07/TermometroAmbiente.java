package lista.ex07;

public class TermometroAmbiente {

	 private String nomeAmbiente;
	    private double temperatura; 

	    public TermometroAmbiente(String nomeAmbiente, double temperaturaInicial) {
	        this.nomeAmbiente = nomeAmbiente;
	        this.temperatura = temperaturaInicial;
	    }

	    public void alterarTemperatura(double novaTemperatura) {
	        this.temperatura = novaTemperatura;
	        System.out.println("Temperatura do ambiente '" + this.nomeAmbiente + "' atualizada para: " + this.temperatura + "°C");
	    }

	    public void registrarLeitura() {
	        System.out.println("Leitura no ambiente '" + this.nomeAmbiente + "': " + this.temperatura + "°C");
	    }

	    public String getNomeAmbiente() {
	        return nomeAmbiente;
	    }

	    public double getTemperatura() {
	        return temperatura;
	    }

	    @Override
	    public String toString() {
	        return "TermometroAmbiente [ambiente=" + nomeAmbiente + ", temperatura=" + temperatura + "°C]";
	    }
}
