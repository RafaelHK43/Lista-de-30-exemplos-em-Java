package lista.ex07;

public class App {

	public static void main(String[] args) {
        System.out.println("--- Exemplo 7: TermometroAmbiente ---");

        TermometroAmbiente ambienteSala = new TermometroAmbiente("Sala de Estar", 22.5);
        TermometroAmbiente ambienteQuarto = new TermometroAmbiente("Quarto Principal", 20.0);

        System.out.println("Estado inicial Termômetro Sala: " + ambienteSala);
        System.out.println("Estado inicial Termômetro Quarto: " + ambienteQuarto);

        System.out.println("\n--- Leituras Iniciais ---");
        ambienteSala.registrarLeitura();
        ambienteQuarto.registrarLeitura();

        System.out.println("\n--- Atualizando Leituras ---");
        ambienteSala.alterarTemperatura(24.0);
        ambienteQuarto.alterarTemperatura(21.5);

        System.out.println("\n--- Leituras Atualizadas ---");
        ambienteSala.registrarLeitura();
        ambienteQuarto.registrarLeitura();

        System.out.println("\nEstado final Termômetro Sala: " + ambienteSala);
        System.out.println("Estado final Termômetro Quarto: " + ambienteQuarto);
    }
}
