package lista.ex04;

public class VentiladorDeMesa {
	
	private boolean ligado;
    private int velocidade; 
    private static final int VELOCIDADE_MAX = 3;

    public VentiladorDeMesa() {
        this.ligado = false;
        this.velocidade = 0;
    }

    public void ligarDesligar() {
        this.ligado = !this.ligado;
        if (!this.ligado) {
            this.velocidade = 0; 
            System.out.println("Ventilador desligado.");
        } else {
            System.out.println("Ventilador ligado.");
        }
    }

    public void aumentarVelocidade() {
        if (this.ligado) {
            if (this.velocidade < VELOCIDADE_MAX) {
                this.velocidade++;
                System.out.println("Velocidade aumentada para: " + this.velocidade);
            } else {
                System.out.println("Velocidade já está no máximo (" + VELOCIDADE_MAX + ").");
            }
        } else {
            System.out.println("O ventilador está desligado. Ligue-o para ajustar a velocidade.");
        }
    }

    public void diminuirVelocidade() {
        if (this.ligado) {
            if (this.velocidade > 0) {
                this.velocidade--;
                if (this.velocidade == 0) {
                    System.out.println("Ventilador desligado pela diminuição de velocidade.");
                    this.ligarDesligar(); 
                } else {
                    System.out.println("Velocidade diminuída para: " + this.velocidade);
                }
            } else {
                System.out.println("O ventilador já está desligado.");
            }
        } else {
            System.out.println("O ventilador já está desligado.");
        }
    }

    public void setVelocidade(int velocidade) {
        if (this.ligado) {
            if (velocidade >= 0 && velocidade <= VELOCIDADE_MAX) {
                this.velocidade = velocidade;
                if (this.velocidade == 0) {
                    System.out.println("Velocidade definida para 0. Ventilador desligando.");
                    this.ligarDesligar();
                } else {
                    System.out.println("Velocidade definida para: " + this.velocidade);
                }
            } else {
                System.out.println("Velocidade inválida. Deve ser entre 0 e " + VELOCIDADE_MAX + ".");
            }
        } else {
            System.out.println("O ventilador está desligado. Ligue-o para ajustar a velocidade.");
        }
    }

    public boolean isLigado() {
        return ligado;
    }

    public int getVelocidade() {
        return velocidade;
    }

    @Override
    public String toString() {
        if (ligado) {
            return "VentiladorDeMesa [ligado=" + ligado + ", velocidade=" + velocidade + "]";
        } else {
            return "VentiladorDeMesa [ligado=" + ligado + "]";
        }
    }

	
		
	}

