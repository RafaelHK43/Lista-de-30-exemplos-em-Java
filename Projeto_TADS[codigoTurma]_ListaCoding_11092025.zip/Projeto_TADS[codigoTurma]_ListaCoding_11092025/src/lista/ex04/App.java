package lista.ex04;

public class App {

	    public static void main(String[] args) {
	        System.out.println("--- Exemplo 4: VentiladorDeMesa ---");

	        VentiladorDeMesa ventilador1 = new VentiladorDeMesa();
	        VentiladorDeMesa ventilador2 = new VentiladorDeMesa();

	        System.out.println("Estado inicial Ventilador 1: " + ventilador1);
	        System.out.println("Estado inicial Ventilador 2: " + ventilador2);

	        System.out.println("\n--- Ações Ventilador 1 ---");
	        ventilador1.ligarDesligar();
	        ventilador1.aumentarVelocidade();
	        ventilador1.aumentarVelocidade();
	        ventilador1.setVelocidade(1); 
	        ventilador1.diminuirVelocidade(); 

	        System.out.println("Estado Ventilador 1 final: " + ventilador1);

	        System.out.println("\n--- Ações Ventilador 2 ---");
	        System.out.println("Tentando mudar velocidade com ventilador desligado:");
	        ventilador2.aumentarVelocidade();
	        ventilador2.diminuirVelocidade();

	        ventilador2.ligarDesligar(); 
	        ventilador2.aumentarVelocidade(); 
	        System.out.println("Estado Ventilador 2: " + ventilador2);
	    }
}
