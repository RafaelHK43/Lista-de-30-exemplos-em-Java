package lista.ex01;

public class LampadaInteligente {
    private boolean ligada;
    private String modo; 

    public LampadaInteligente() {
        this.ligada = false;
        this.modo = "desligada";
    }

    public void ligarDesligar() {
        this.ligada = !this.ligada;
        if (!this.ligada) {
            this.modo = "desligada";
        }
        System.out.println("Lâmpada " + (this.ligada ? "ligada" : "desligada"));
    }

    public void setModo(String modo) {
        if (this.ligada) {
            this.modo = modo;
            System.out.println("Modo da lâmpada alterado para: " + this.modo);
        } else {
            System.out.println("Não é possível alterar o modo com a lâmpada desligada.");
        }
    }

    public boolean isLigada() {
        return ligada;
    }

    public String getModo() {
        return modo;
    }

    @Override
    public String toString() {
        return "LampadaInteligente [ligada=" + ligada + ", modo=" + modo + "]";
    }
}
