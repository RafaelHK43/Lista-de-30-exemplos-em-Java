package lista.ex01;

public class App {
	 
	public static void main(String[] args) {
	        System.out.println("--- Exemplo 1: LampadaInteligente ---");

	        LampadaInteligente lampada1 = new LampadaInteligente();
	        LampadaInteligente lampada2 = new LampadaInteligente();

	        System.out.println("Estado inicial Lâmpada 1: " + lampada1);
	        System.out.println("Estado inicial Lâmpada 2: " + lampada2);

	        lampada1.ligarDesligar();
	        lampada1.setModo("leitura");

	        lampada2.ligarDesligar();
	        lampada2.setModo("relax");

	        System.out.println("Estado Lâmpada 1 após alteração: " + lampada1);
	        System.out.println("Estado Lâmpada 2 após alteração: " + lampada2);

	        lampada1.ligarDesligar(); 
	        lampada1.setModo("relax"); 

	        System.out.println("Estado Lâmpada 1 final: " + lampada1);
	        System.out.println("Estado Lâmpada 2 final: " + lampada2);
	    }
}
