package lista.ex09;

public class PlayerDeMusica {

	private String faixaAtual;
    private String status; 

    public PlayerDeMusica(String faixaInicial) {
        this.faixaAtual = faixaInicial;
        this.status = "parado";
    }

    public void tocar() {
        if (this.status.equals("parado") || this.status.equals("pausado")) {
            this.status = "reproduzindo";
            System.out.println("Reproduzindo: " + this.faixaAtual);
        } else {
            System.out.println("A faixa '" + this.faixaAtual + "' já está em reprodução.");
        }
    }

    public void pausar() {
        if (this.status.equals("reproduzindo")) {
            this.status = "pausado";
            System.out.println("Faixa pausada: " + this.faixaAtual);
        } else {
            System.out.println("A faixa não está em reprodução para ser pausada.");
        }
    }

    public void parar() {
        if (!this.status.equals("parado")) {
            this.status = "parado";
            System.out.println("Reprodução parada: " + this.faixaAtual);
        } else {
            System.out.println("O player já está parado.");
        }
    }

    public void selecionarFaixa(String novaFaixa) {
        if (!this.status.equals("reproduzindo")) {
            this.faixaAtual = novaFaixa;
            this.status = "parado"; 
            System.out.println("Faixa selecionada: " + this.faixaAtual);
        } else {
            System.out.println("Não é possível selecionar nova faixa enquanto reproduzindo. Pare ou pause primeiro.");
        }
    }

    public String getFaixaAtual() {
        return faixaAtual;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "PlayerDeMusica [faixa=" + faixaAtual + ", status=" + status + "]";
    }
}
