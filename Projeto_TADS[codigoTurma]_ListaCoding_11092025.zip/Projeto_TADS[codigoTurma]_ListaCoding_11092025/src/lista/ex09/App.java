package lista.ex09;

public class App {

	  public static void main(String[] args) {
	        System.out.println("--- Exemplo 9: PlayerDeMusica ---");

	        PlayerDeMusica player1 = new PlayerDeMusica("Música A");
	        PlayerDeMusica player2 = new PlayerDeMusica("Outra Faixa B");

	        System.out.println("Estado inicial Player 1: " + player1);
	        System.out.println("Estado inicial Player 2: " + player2);

	    
	        System.out.println("\n--- Ações Player 1 ---");
	        player1.tocar();
	        player1.pausar();
	        player1.tocar(); 
	        player1.parar();

	        System.out.println("\nEstado Player 1: " + player1);

	      
	        System.out.println("\n--- Ações Player 2 ---");
	        player2.selecionarFaixa("Faixa C");
	        player2.tocar();
	        player2.selecionarFaixa("Faixa D"); 
	        player2.parar();
	        player2.selecionarFaixa("Faixa D"); 
	        player2.tocar();

	        System.out.println("\nEstado final Player 1: " + player1);
	        System.out.println("Estado final Player 2: " + player2);
	    }
}
