package lista.ex02;

public class App {
	public static void main(String[] args) {
        System.out.println("--- Exemplo 2: PortaComTranca ---");

        PortaComTranca porta1 = new PortaComTranca();
        PortaComTranca porta2 = new PortaComTranca();

        System.out.println("Estado inicial Porta 1: " + porta1);
        System.out.println("Estado inicial Porta 2: " + porta2);

        porta1.abrir(); 
        porta2.trancar();
        porta2.abrir(); 

        System.out.println("\nEstado Porta 1 após tentativa de abrir: " + porta1);
        System.out.println("Estado Porta 2 após tentativa de abrir: " + porta2);

        porta2.destrancar();
        porta2.abrir(); 

        System.out.println("\nEstado Porta 2 após destrancar e tentar abrir: " + porta2);
    }
}
