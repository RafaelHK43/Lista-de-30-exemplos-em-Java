package lista.ex02;

public class PortaComTranca {
	  
	private boolean aberta;
	    private boolean trancada;

	    public PortaComTranca() {
	        this.aberta = false;
	        this.trancada = false;
	    }

	    public void abrir() {
	        if (!this.trancada) {
	            this.aberta = true;
	            System.out.println("A porta foi aberta.");
	        } else {
	            System.out.println("A porta está trancada e não pode ser aberta.");
	        }
	    }

	    public void fechar() {
	        this.aberta = false;
	        System.out.println("A porta foi fechada.");
	    }

	    public void trancar() {
	        this.trancada = true;
	        System.out.println("A porta foi trancada.");
	    }

	    public void destrancar() {
	        this.trancada = false;
	        System.out.println("A porta foi destrancada.");
	    }

	    public boolean isAberta() {
	        return aberta;
	    }

	    public boolean isTrancada() {
	        return trancada;
	    }

	    @Override
	    public String toString() {
	        return "PortaComTranca [aberta=" + aberta + ", trancada=" + trancada + "]";
	    }
	}

