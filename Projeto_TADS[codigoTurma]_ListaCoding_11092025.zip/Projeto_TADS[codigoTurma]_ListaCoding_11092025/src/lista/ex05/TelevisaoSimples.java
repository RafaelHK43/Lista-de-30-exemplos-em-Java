package lista.ex05;

public class TelevisaoSimples {

	private boolean ligada;
    private int canalAtual;
    private int volumeAtual;
    private static final int CANAL_MAXIMO = 100; 
    private static final int VOLUME_MAXIMO = 100; 

    public TelevisaoSimples() {
        this.ligada = false;
        this.canalAtual = 1;
        this.volumeAtual = 10;
    }

    public void ligarDesligar() {
        this.ligada = !this.ligada;
        System.out.println("TV " + (this.ligada ? "ligada." : "desligada."));
    }

    public void trocarCanal(int novoCanal) {
        if (this.ligada) {
            if (novoCanal >= 1 && novoCanal <= CANAL_MAXIMO) {
                this.canalAtual = novoCanal;
                System.out.println("Canal alterado para: " + this.canalAtual);
            } else {
                System.out.println("Canal inválido. Digite um número entre 1 e " + CANAL_MAXIMO + ".");
            }
        } else {
            System.out.println("A TV está desligada. Ligue-a para trocar de canal.");
        }
    }

    public void aumentarVolume() {
        if (this.ligada) {
            if (this.volumeAtual < VOLUME_MAXIMO) {
                this.volumeAtual++;
                System.out.println("Volume aumentado para: " + this.volumeAtual);
            } else {
                System.out.println("Volume já está no máximo (" + VOLUME_MAXIMO + ").");
            }
        } else {
            System.out.println("A TV está desligada. Ligue-a para ajustar o volume.");
        }
    }

    public void diminuirVolume() {
        if (this.ligada) {
            if (this.volumeAtual > 0) {
                this.volumeAtual--;
                System.out.println("Volume diminuído para: " + this.volumeAtual);
            } else {
                System.out.println("Volume já está no mínimo (0).");
            }
        } else {
            System.out.println("A TV está desligada. Ligue-a para ajustar o volume.");
        }
    }

    public boolean isLigada() {
        return ligada;
    }

    public int getCanalAtual() {
        return canalAtual;
    }

    public int getVolumeAtual() {
        return volumeAtual;
    }

    @Override
    public String toString() {
        return "TelevisaoSimples [ligada=" + ligada + ", canal=" + canalAtual + ", volume=" + volumeAtual + "]";
    }
}
