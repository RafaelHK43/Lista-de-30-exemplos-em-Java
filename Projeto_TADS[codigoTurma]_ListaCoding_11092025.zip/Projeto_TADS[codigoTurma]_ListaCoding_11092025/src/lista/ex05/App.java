package lista.ex05;

public class App {
	 public static void main(String[] args) {
	        System.out.println("--- Exemplo 5: TelevisaoSimples ---");

	        TelevisaoSimples tv1 = new TelevisaoSimples();
	        TelevisaoSimples tv2 = new TelevisaoSimples();

	        System.out.println("Estado inicial TV 1: " + tv1);
	        System.out.println("Estado inicial TV 2: " + tv2);

	        System.out.println("\n--- Configurações TV 1 ---");
	        tv1.ligarDesligar();
	        tv1.trocarCanal(5);
	        tv1.aumentarVolume();
	        tv1.aumentarVolume();
	        tv1.trocarCanal(15);

	        System.out.println("Estado TV 1: " + tv1);

	        System.out.println("\n--- Configurações TV 2 ---");
	        tv2.ligarDesligar();
	        tv2.trocarCanal(20);
	        tv2.diminuirVolume();
	        tv2.aumentarVolume(); 
	        tv2.aumentarVolume();

	        System.out.println("Estado TV 2: " + tv2);

	        tv1.ligarDesligar();
	        tv1.trocarCanal(10); 

	        System.out.println("\nEstado final TV 1: " + tv1);
	        System.out.println("Estado final TV 2: " + tv2);
	    }
}
